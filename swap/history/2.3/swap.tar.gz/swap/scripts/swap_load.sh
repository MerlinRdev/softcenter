#! /bin/sh

sh /jffs/softcenter/scripts/swapmake.sh load
