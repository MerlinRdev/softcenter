#! /bin/sh

# 导入skipd数据
eval `dbus export swap`
# 引用环境变量等
source /jffs/softcenter/scripts/base.sh

check_usb_status(){
	
	# 1	没有找到符合格式要求的磁盘！
	# 2	swap分区已经加载
	# 3	没有找到虚拟缓存文件，需要创建！
	# 4	找到swapfile，但是尝试挂载失败！

if [ -z "/tmp/mnt/$swap_disk" ];then
	dbus set swap_warnning="1"
else
	ext_type=`/bin/mount | grep -E '$swap_disk' | sed -n 1p | cut -d" " -f5`
	dbus set swap_usb_type="$ext_type"
	for part in /tmp/mnt/$swap_disk
	do
		if [ -f /tmp/mnt/$swap_disk/swapfile ];then
			sleep 1
			SWAPTOTAL=`free|grep Swap|awk '{print $2}'`
			SWAPUSED=`free|grep Swap|awk '{print $3}'`
			if [ "$SWAPTOTAL" != "0" ];then
				dbus set swap_warnning="2"
			else
				swapon /tmp/mnt/$swap_disk/swapfile
				if [ "$?" == "0" ];then
					SWAPTOTAL=`free|grep Swap|awk '{print $2}'`
					SWAPUSED=`free|grep Swap|awk '{print $3}'`
					dbus set swap_warnning="2"
					exit
				else
					SWAPTOTAL=`free|grep Swap|awk '{print $2}'`
					SWAPUSED=`free|grep Swap|awk '{print $3}'`
					dbus set swap_warnning="4"
				fi
			fi
		else
			if [ "$ext_type" == "ext2" ] || [ "$ext_type" == "ext3" ] || [ "$ext_type" == "ext4" ] || [ "$ext_type" == "tfat" ] || [ "$ext_type" == "tntfs" ] || [ "$ext_type" == "vfat" ];then
				dbus set swap_warnning="3"
			else
				dbus set swap_warnning="1"
		fi
	done
fi
}


mkswap(){
	if [ "$swap_warnning" == "3" ];then
		[ "$swap_size" == "1" ] && size=256144
		[ "$swap_size" == "2" ] && size=524288
		[ "$swap_size" == "3" ] && size=1048576
		if [ ! -f  /tmp/mnt/$swap_disk/swapfile ];then
			dd if=/dev/zero of=/tmp/mnt/$swap_disk/swapfile bs=1024 count="$size"
			/sbin/mkswap /tmp/mnt/$swap_disk/swapfile
			chmod 0600 /tmp/mnt/$swap_disk/swapfile
			swapon /tmp/mnt/$swap_disk/swapfile
		fi
	fi
}

case $1 in
start)
	check_usb_status
	;;
load)
	check_usb_status
	mkswap
	;;
unload)
	usb_disk=`/bin/mount | grep -E 'mnt' | sed -n 1p | cut -d" " -f3`
	swapoff $usb_disk/swapfile
	rm -rf $usb_disk/swapfile
	;;
check)
	check_usb_status
	;;
esac
