#!/bin/sh

rm -f /jffs/softcenter/scripts/speedtest.sh
rm -f /jffs/softcenter/bin/speedtest
rm -f /jffs/softcenter/webs/Module_speedtest.asp
