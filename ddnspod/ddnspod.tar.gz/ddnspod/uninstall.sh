#!/bin/sh

rm -rf /jffs/softcenter/scripts/ddnspod_config.sh
rm -rf /jffs/softcenter/scripts/ddnspod.sh
rm -rf /jffs/softcenter/webs/Module_ddnspod.asp
rm -rf /jffs/softcenter/res/icon-ddnspod.png
rm -rf /jffs/softcenter/res/md5.js
rm -rf /jffs/softcenter/res/rsa.js
rm -rf /jffs/softcenter/res/sha1.js
rm -rf /jffs/softcenter/scripts/ddnspod_config.sh
rm -rf /jffs/softcenter/init.d/S99ddnspod.sh
