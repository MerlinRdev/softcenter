#!/bin/sh

sh /jffs/softcenter/scripts/aria2_run.sh stop
rm -rf /jffs/softcenter/bin/aria2*
rm -rf /jffs/softcenter/perp/aria2
rm -rf /jffs/softcenter/scripts/aria2_config.sh
rm -rf /jffs/softcenter/scripts/aria2_status.sh
rm -rf /jffs/softcenter/res/aria2_check.html
rm -rf /jffs/softcenter/res/icon-aria2.png
rm -rf /jffs/softcenter/webs/Module_aria2.asp
rm -fr /jffs/softcenter/scripts/uninstall_aria2.sh
